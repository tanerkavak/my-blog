# Proje: Godot + LLM Wiki

## YapÄ±
- `wiki/raw/`: ham kaynaklar. ASLA dÃ¼zenleme, sadece oku.
- `wiki/pages/`: senin sahip olduÄŸun markdown sayfalarÄ±.
- `wiki/index.md`: her sayfa burada listelenir.
- `wiki/log.md`: her iÅŸlem buraya eklenir.

## Ä°ÅŸlemler
1. **Ingest**: raw/ iÃ§ine yeni kaynak gelince oku, Ã¶zetle,
   ilgili sayfalarÄ± oluÅŸtur/gÃ¼ncelle, index ve log'u gÃ¼ncelle.
2. **Query**: Ã¶nce index.md'ye bak, ilgili sayfalarÄ± oku, cevapla.
   DeÄŸerli cevaplarÄ± yeni sayfa olarak kaydet.
3. **Lint**: Ã§eliÅŸkileri, eski bilgileri, yetim sayfalarÄ± ve
   eksik Ã§apraz baÄŸlantÄ±larÄ± tespit et.

## Kurallar
- Sayfalar arasÄ± baÄŸlantÄ±: `[[sayfa-adi]]`
- Dosya adlarÄ±: kÃ¼Ã§Ã¼k harf, tire ile (`savas-sistemi.md`)
- Her sayfanÄ±n baÅŸÄ±nda kaynak listesi bulunur.
- Kod kurallarÄ±: GDScript, `snake_case`, tip belirtmeli deÄŸiÅŸkenler.
- `.env` dosyasÄ±nÄ± asla okuma veya commit'leme.