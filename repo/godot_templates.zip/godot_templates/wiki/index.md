# Wiki Index
Her sayfa iÃ§in tek satÄ±r: [[sayfa]] - kÄ±sa Ã¶zet