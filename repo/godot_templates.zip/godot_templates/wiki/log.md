# Log
BiÃ§im: `## [YYYY-MM-DD] iÅŸlem | baÅŸlÄ±k`